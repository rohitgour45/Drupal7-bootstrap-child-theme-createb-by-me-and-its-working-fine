jQuery(document).ready(function ($) {

	// backstretch function
	$('[data-backstretch]').each(function(){
		$(this).backstretch($(this).data('backstretch'));
	});

	// faq accrodion
	$('.view-ug-faq .views-field-title').click(function(){
		$('.views-row').removeClass('open');
		$(this).parent().addClass('open');
	});

	// frontpage slider adjustment
	var wd = $('.view-ug-frontpage-slider .flex-caption').width();
	$('.view-ug-frontpage-slider .flex-caption').css('margin-left',-wd/2);

	if ($(window).width() < 767) {
		$('#navbar #block-locale-language').insertAfter('#navbar #block-menu-menu-undergraduate-top-menu');
	}

	$('.colorbox-inline').filter(function () { return $.trim(this.innerHTML) == "" }).remove();

	$('.slides li').each(function(){
	  var image = $(this).find('img').attr('src');
	  $(this).css('backgroundImage',"url("+image+")");
	})

	if ($(window).width() > 1024) {
		var theHeight = (($(window).height()-$('#navbar').height())-40);
		$("#flexslider-1 ul li .views-field-field-slider-image img").css({"height" :  theHeight+'px'});
	}

	//window.viewportUnitsBuggyfill.init();

	if ($(window).width() > 768) {
		$('.footer .menu').columnize({ columns: 2 });
	}

});